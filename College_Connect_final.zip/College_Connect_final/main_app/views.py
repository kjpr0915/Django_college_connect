import json
import requests
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render, reverse
from django.views.decorators.csrf import csrf_exempt

from .EmailBackend import EmailBackend
from .models import Attendance, Session, Subject 

# Create your views here.

from django.shortcuts import render
from django.http import JsonResponse
import joblib
import numpy as np
from .forms import PredictionForm

# Load models and scaler
CLASSIFICATION_MODEL_PATH = 'models\classification_model.pkl'
REGRESSION_MODEL_PATH = 'models\pregression_model.pkl'
SCALER_PATH = 'models\scaler.pkl'

classifier = joblib.load(CLASSIFICATION_MODEL_PATH)
regressor = joblib.load(REGRESSION_MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

def predict(request):
    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        form = PredictionForm(request.POST)
        if form.is_valid():
            try:
                # Extract cleaned data from the form
                features = [
                    form.cleaned_data['cgpa'],
                    form.cleaned_data['major_projects'],
                    form.cleaned_data['workshops'],
                    form.cleaned_data['mini_projects'],
                    form.cleaned_data['skills'],
                    form.cleaned_data['communication'],
                    1 if form.cleaned_data['internship'] == 'Yes' else 0,
                    1 if form.cleaned_data['hackathon'] == 'Yes' else 0,
                    form.cleaned_data['twelfth_percent'],
                    form.cleaned_data['tenth_percent'],
                    form.cleaned_data['backlogs'],
                ]

                # Convert to numpy array and scale the input
                features = np.array(features).reshape(1, -1)
                features_scaled = scaler.transform(features)

                # Predict Placement Status
                placement_status = classifier.predict(features_scaled)[0]

                if placement_status == 1:  # If Placed
                    salary = regressor.predict(features_scaled)[0]
                    return JsonResponse({
                        'status': 'success',
                        'placement': 'Placed',
                        'salary': f'{salary:.2f}',
                    })
                else:
                    return JsonResponse({
                        'status': 'success',
                        'placement': 'Not Placed',
                        'salary': '0',
                    })
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': str(e)})
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid form data', 'errors': form.errors})
    else:
        form = PredictionForm()
    return render(request, 'student_template\predict.html', {'form': form})

















def login_page(request):
    if request.user.is_authenticated:
        if request.user.user_type == '1':
            return redirect(reverse("admin_home"))
        elif request.user.user_type == '2':
            return redirect(reverse("staff_home"))
        else:
            return redirect(reverse("student_home"))
    return render(request, 'main_app/login.html')


def doLogin(request, **kwargs):
    if request.method != 'POST':
        return HttpResponse("<h4>Denied</h4>")
    else:
        #Google recaptcha
        captcha_token = request.POST.get('g-recaptcha-response')
        captcha_url = "https://www.google.com/recaptcha/api/siteverify"
        captcha_key = "6LfTGD4qAAAAALtlli02bIM2MGi_V0cUYrmzGEGd"
        data = {
            'secret': captcha_key,
            'response': captcha_token
        }
        # Make request
       
        #Authenticate
        user = EmailBackend.authenticate(request, username=request.POST.get('email'), password=request.POST.get('password'))
        if user != None:
            login(request, user)
            if user.user_type == '1':
                return redirect(reverse("admin_home"))
            elif user.user_type == '2':
                return redirect(reverse("staff_home"))
            else:
                return redirect(reverse("student_home"))
        else:
            messages.error(request, "Invalid details")
            return redirect("/")



def logout_user(request):
    if request.user != None:
        logout(request)
    return redirect("/")


@csrf_exempt
def get_attendance(request):
    subject_id = request.POST.get('subject')
    session_id = request.POST.get('session')
    try:
        subject = get_object_or_404(Subject, id=subject_id)
        session = get_object_or_404(Session, id=session_id)
        attendance = Attendance.objects.filter(subject=subject, session=session)
        attendance_list = []
        for attd in attendance:
            data = {
                    "id": attd.id,
                    "attendance_date": str(attd.date),
                    "session": attd.session.id
                    }
            attendance_list.append(data)
        return JsonResponse(json.dumps(attendance_list), safe=False)
    except Exception as e:
        return None


def showFirebaseJS(request):
    data = """
    // Give the service worker access to Firebase Messaging.
// Note that you can only use Firebase Messaging here, other Firebase libraries
// are not available in the service worker.
importScripts('https://www.gstatic.com/firebasejs/7.22.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/7.22.1/firebase-messaging.js');

// Initialize the Firebase app in the service worker by passing in
// your app's Firebase config object.
// https://firebase.google.com/docs/web/setup#config-object
firebase.initializeApp({
    apiKey: "",
    authDomain: "sms-with-django.firebaseapp.com",
    databaseURL: "https://sms-with-django.firebaseio.com",
    projectId: "sms-with-django",
    storageBucket: "sms-with-django.appspot.com",
    messagingSenderId: "945324593139",
    appId: "1:945324593139:web:03fa99a8854bbd38420c86",
    measurementId: "G-2F2RXTL9GT"
});

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();
messaging.setBackgroundMessageHandler(function (payload) {
    const notification = JSON.parse(payload);
    const notificationOption = {
        body: notification.body,
        icon: notification.icon
    }
    return self.registration.showNotification(payload.notification.title, notificationOption);
});
    """
    return HttpResponse(data, content_type='application/javascript')



# views.py
import csv
from django.http import HttpResponse, FileResponse
from django.db.models import Sum
from .models import Student, StudentResult, Subject, Course
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from .forms import ExportForm  # Import the form

def export_students(request):
    # Initialize the form and handle the POST request
    form = ExportForm(request.POST or None)

    # If the form is valid, handle the export
    if form.is_valid():
        export_format = form.cleaned_data['format'].lower()
        selected_course = form.cleaned_data['course']  # Get the selected course

        # Fetch student data filtered by selected course
        students = Student.objects.filter(course=selected_course).select_related('admin', 'course', 'session')
        student_results = StudentResult.objects.select_related('subject', 'student')

        # Organize results by student and subject
        results_dict = {}
        for result in student_results:
            student_id = result.student.id
            subject_id = result.subject.id
            if student_id not in results_dict:
                results_dict[student_id] = {}
            results_dict[student_id][subject_id] = result.test + result.exam

        # Handle CSV Export
        if export_format == 'csv':
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="students_with_subject_results.csv"'
            writer = csv.writer(response)
            writer.writerow(['Name', 'Email', 'Address', 'Course', 'Subject', 'Results'])

            for student in students:
                subjects = Subject.objects.filter(course=student.course)
                for subject in subjects:
                    result = results_dict.get(student.id, {}).get(subject.id, 'N/A')
                    writer.writerow([
                        f"{student.admin.first_name} {student.admin.last_name}",
                        student.admin.email,
                        student.admin.address,
                        student.course.name if student.course else 'N/A',
                        subject.name,
                        result,
                    ])
            return response

        # Handle PDF Export
        elif export_format == 'pdf':
            buffer = BytesIO()
            pdf_canvas = canvas.Canvas(buffer, pagesize=letter)
            pdf_canvas.setFont("Helvetica", 10)
            line_height = 20
            y_position = 750  # Starting Y position for content

            # Add title
            pdf_canvas.setFont("Helvetica-Bold", 14)
            pdf_canvas.drawString(200, y_position, f"Students with Subject Results for {selected_course.name}")
            y_position -= line_height * 2  # Move down

            # Add table headers
            pdf_canvas.setFont("Helvetica-Bold", 10)
            headers = ['Name', 'Email', 'Address', 'Course', 'Subject', 'Results']
            x_positions = [50, 150, 250, 350, 450, 550]  # Adjust column spacing
            for x, header in zip(x_positions, headers):
                pdf_canvas.drawString(x, y_position, header)
            y_position -= line_height

            # Add data rows
            pdf_canvas.setFont("Helvetica", 10)
            for student in students:
                subjects = Subject.objects.filter(course=student.course)
                for subject in subjects:
                    if y_position < 50:  # Create a new page if the content exceeds the current page
                        pdf_canvas.showPage()
                        pdf_canvas.setFont("Helvetica", 10)
                        y_position = 750  # Reset Y position

                    result = results_dict.get(student.id, {}).get(subject.id, 'N/A')
                    data = [
                        f"{student.admin.first_name} {student.admin.last_name}",
                        student.admin.email,
                        student.admin.address,
                        student.course.name if student.course else 'N/A',
                        subject.name,
                        str(result),
                    ]
                    for x, value in zip(x_positions, data):
                        pdf_canvas.drawString(x, y_position, value)
                    y_position -= line_height

            pdf_canvas.save()
            buffer.seek(0)
            return FileResponse(buffer, as_attachment=True, filename=f'{selected_course.name}_students_with_subject_results.pdf')

        # Default to CSV if format is invalid
        else:
            return HttpResponse("Invalid format", status=400)
    
    # If the form is not valid or not yet submitted, show the form
    return render(request, 'hod_template\export_students.html', {'form': form})
